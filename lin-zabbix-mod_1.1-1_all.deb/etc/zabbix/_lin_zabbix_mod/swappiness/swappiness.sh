#!/bin/bash

memtotal=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}')	#Значение общей памяти системы
sys_swap=$(grep vm.swappiness /etc/sysctl.conf | awk '{print $3}')	#Значение срабатывания SWAP в sysctl


#=========================================================================================
#=========================================================================================
#Проверка параметра swappiness в sysctl.conf

function sysctl {
check_sys(){
smallmem=4194304	#Маленькая память равна 4 Гб
mediummem=8388608	#Средняя память равно 8 Гб
bigmem=16777216		#Большая память равна 16 Гб

#Если ОЗУ системы меньше 4 Гб, и если значение vm.swap в sysctl не равно 60, то передает значение 1, иначе 5
if (($memtotal <= $smallmem))
then
    if [ $sys_swap -ne 60 ]
        then echo 1
        else echo 5
    fi
fi


#Если ОЗУ системы больше 4 Гб и меньше или равно 8 Гб, и если значение vm.swap в sysctl не равно 40, то передает значение 2, иначе 5
if (($memtotal > $smallmem)) && (($memtotal <= $mediummem))
then
    if [ $sys_swap -ne 40 ]
        then echo 2
        else echo 5
    fi
fi


#Если ОЗУ системы больше 8 Гб и меньше или равно 16 Гб, и если значение vm.swap в sysctl не равно 50, то передает значение 3, иначе 5

if (($memtotal > $mediummem)) && (($memtotal <= $bigmem))
then
    if [ $sys_swap -ne 15 ]
        then echo 3
        else echo 5
    fi
fi


#Если ОЗУ системы больше 16 Гб и если значение vm.swap в sysctl не равно 10, то передает значение 4, иначе 5
if (($memtotal > $bigmem))
then
    if [ $sys_swap -ne 10 ]
        then echo 4
        else echo 5
    fi
fi
}
#Разяъснение значений 0 1 2 3 4 5
# 0 - Значит параметр vm.swappiness не настроен в /etc/sysctl.conf
# 1 - Значит что для системы с меньше чем 4 Гб ОЗУ, параметр vm.swappiness в /etc/sysctl.conf настроен не верно, должно быть равно 60
# 2 - Значит что для системы с больше чем 4 Гб ОЗУ и меньше-равно 8 Гб, параметр vm.swappiness в /etc/sysctl.conf настроен не верно, должно быть равно 40
# 3 - Значит что для системы с больше чем 8 Гб ОЗУ и меньге-равно 16 Гб, параметр vm.swappiness в /etc/sysctl.conf настроен не верно, должно быть равно 15
# 4 - Значит что для системы с больше чем 16 Гб ОЗУ, параметр vm.swappiness в /etc/sysctl.conf настроен не верно, должно быть равно 10
# 5 - Всё настроено правильно.

# Проверка есть ли строка со значением vm.swappiness в syscrl.conf
if grep vm.swappiness /etc/sysctl.conf > /dev/nul
then check_sys
else echo 0
fi
}


#=========================================================================================
#=========================================================================================
# Проверка применен ли параметр swappiness в данный момент (онлайн)
# Если значение swappiness в системе (proc) не равен значению в sysctl.conf, то значит параметр из sysctl.conf не применена,
# поэтому отправляется значение 0 т.е. алерт, иначе (если равно) то настройки применены, отправляется значение 1.
function proc {
proc_swap=$(cat /proc/sys/vm/swappiness)
if [ $proc_swap -ne $sys_swap ]
then echo 0
else echo 1
fi
}

$1